export interface Stats {
    totalCustomers: number;
    totalInvoices: number;
    totalBilled: number;
}